<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\MatchModel;

class Question extends Model
{
    use HasFactory;

    public function match()
    {
        return $this->belongsTo(MatchModel::class);
    }

    public function options()
    {
        return $this->hasMany(Option::class);
    }

    public function bets()
    {
        return $this->hasMany(Bet::class);
    }
}