@extends($activeTemplate.'layouts.frontend')
@section('content')
    @include($activeTemplate.'partials.breadcrumb')
    <section class="dashboard-section bg--section pt-120">
        <div class="container">
            <div class="pb-120">
                <div class="text-end mb-4">
                    <a href="{{route('user.withdraw')}}" class="cmn--btn btn--sm">@lang('Retirar Ahora')</a>
                </div>
                <div class="table-responsive">
                    <table class="table cmn--table">
                        <thead>
                            <tr>
                                <th>@lang('N° de Transacción ID')</th>
                                <th>@lang('Metodo')</th>
                                <th>@lang('Monto')</th>
                                <th>@lang('Queda en balance')</th>
                                <th>@lang('Por Acreditarse ')</th>
                                <th>@lang('Cambio')</th>
                                <th>@lang('Retirable')</th>
                                <th>@lang('Estado')</th>
                                <th>@lang('Fecha')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($withdraws as $k=>$data)
                                <tr>
                                    <td data-label="#@lang('N° de Transacción ID')">{{$data->trx}}</td>
                                    <td data-label="@lang('Metodo')">{{ __($data->method->name) }}</td>
                                    <td data-label="@lang('Monto')">
                                        <strong>{{showAmount($data->amount)}} {{__($general->cur_text)}}</strong>
                                    </td>
                                    <td data-label="@lang('Queda en balance')" class="text-successs">
                                        {{showAmount($data->charge)}} {{__($general->cur_text)}}
                                    </td>
                                    <td data-label="@lang('Por acreditarse')" class="text-info">
                                        {{showAmount($data->after_charge)}} {{__($general->cur_text)}}
                                    </td>
                                    <td data-label="@lang('Cambio')">
                                        {{showAmount($data->rate)}} {{__($data->currency)}}
                                    </td>
                                    <td data-label="@lang('Retirable')" class="text-success">
                                        <strong class="text--base">{{showAmount($data->final_amount)}} {{__($data->currency)}}</strong>
                                    </td>
                                    <td data-label="@lang('Estado')">
                                        @if($data->status == 2)
                                            <span class="badge badge--warning">@lang('En Proceso')</span>
                                        @elseif($data->status == 1)
                                            <span class="badge badge--success">@lang('Completado')</span>
                                            <a href="javascript:void(0)" class="badge badge--info approveBtn" data-admin_feedback="{{$data->admin_feedback}}"><i class="fa fa-info"></i></a>
                                        @elseif($data->status == 3)
                                            <span class="badge badge--danger">@lang('Rechazado')</span>
                                            <a class="badge badge--info approveBtn" data-admin_feedback="{{$data->admin_feedback}}"><i class="fa fa-info"></i></a>
                                        @endif

                                    </td>
                                    <td data-label="@lang('Tiempo Estimado')">
                                        <i class="fa fa-calendar text--base"></i> {{showDateTime($data->created_at)}}
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-muted text-center" colspan="100%">{{ __($emptyMessage) }}</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <ul class="pagination justify-content-end">
                    {{$withdraws->links()}}
                </ul>
            </div>
        </div>
    </section>


    {{-- Detail MODAL --}}
    <div id="detailModal" class="modal fade cmn--modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">@lang('Detalles')</h5>
                    <span data-bs-dismiss="modal">
                        <i class="las la-times"></i>
                    </span>
                </div>
                <div class="modal-body">

                    <div class="withdraw-detail"></div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--danger" data-bs-dismiss="modal">@lang('Cerrar')</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script>
        (function($){
            "use strict";
            $('.approveBtn').on('click', function() {
                var modal = $('#detailModal');
                var feedback = $(this).data('admin_feedback');
                modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
                modal.modal('show');
            });
        })(jQuery);

    </script>
@endpush
