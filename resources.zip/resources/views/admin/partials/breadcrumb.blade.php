

<div class="row align-items-center mb-30 justify-content-between">
    <div class="col-lg-4 col-sm-6">
        <h6 class="page-title">{{ __($pageTitle) }}</h6>
    </div>
    <div class="col-lg-8 col-sm-6 text-sm-right mt-sm-0 mt-3 right-part">
        @stack('breadcrumb-plugins')
    </div>
</div>
