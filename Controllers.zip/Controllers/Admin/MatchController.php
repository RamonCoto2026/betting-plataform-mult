<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\League;
use Illuminate\Http\Request;
use App\Models\MatchModel as MatchAlias;

class MatchController extends Controller
{
    protected $pageTitle;
    protected $emptyMessage;

    protected function filterMatches($type){

        $matches = MatchAlias::latest();
        $this->pageTitle    = ucfirst($type). ' Matches';
        $this->emptyMessage = "No $type match found";

        if($type != 'all'){
            $matches = $matches->$type();
        }

        if(request()->search){
            $search             = request()->search;
            $matches            = $matches->where('name', 'like',"%$search%");
            $this->pageTitle    = "Search Result for '$search'";
        }

        return $matches->with(['category','league', 'questions'])->paginate(getPaginate());
    }

    public function index()
    {
        $segments       = request()->segments();
        $type           = end($segments);
        $matches        = $this->filterMatches(end($segments));
        $leagues        = League::latest()->get();
        $pageTitle      = $this->pageTitle;
        $emptyMessage   = $this->emptyMessage;
        return view('admin.match.index',compact('pageTitle', 'matches', 'emptyMessage', 'leagues'));
    }

    public function store(Request $request, $id=0)
    {
        $request->validate([
            'name'              => 'required',
            'league_id'         => 'required|integer|gt:0',
            'beginning_time'    => 'required|date_format:Y-m-d h:i a',
            'finishing_time'    => 'required|date_format:Y-m-d h:i a|after:start_time',
            'team_home'         => 'nullable|string|max:100',
            'team_away'         => 'nullable|string|max:100',
            'team_home_image'   => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'team_away_image'   => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        $league = League::findOrFail($request->league_id);

        if($id){
            $match = MatchAlias::findOrFail($id);
            $notification = 'Match updated successfully';
            $match->status = $request->status ? 1 : 0;
        }else{
            $match = new MatchAlias();
            $notification = 'Match added successfully';
        }

        $match->name        = $request->name;
        $match->category_id = $league->category->id;
        $match->league_id   = $league->id;
        $match->start_time  = $request->beginning_time;
        $match->end_time    = $request->finishing_time;
        $match->team_home   = $request->team_home;
        $match->team_away   = $request->team_away;

        if($request->hasFile('team_home_image')){
            $image = $request->file('team_home_image');
            $filename = time() . '_home.' . $image->getClientOriginalExtension();
            $image->move(public_path('assets/images/teams'), $filename);
            $match->team_home_image = $filename;
        }

        if($request->hasFile('team_away_image')){
            $image = $request->file('team_away_image');
            $filename = time() . '_away.' . $image->getClientOriginalExtension();
            $image->move(public_path('assets/images/teams'), $filename);
            $match->team_away_image = $filename;
        }

        $match->save();

        $notify[] = ['success', $notification];
        return back()->withNotify($notify);
    }
}